package sample;

import javafx.scene.control.Label;

public class Depth extends Controller{

//    private Label label = label1;
//
//    public void Key(){
//        label1.setStyle("-fx-background-color:blue");
//    }
}
