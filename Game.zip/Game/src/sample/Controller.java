package sample;


import javafx.event.ActionEvent;
import javafx.fxml.FXML;
import javafx.scene.control.Button;
import javafx.scene.control.Label;

import javafx.scene.layout.AnchorPane;
import javafx.scene.layout.GridPane;
import javafx.scene.shape.Circle;

import javax.xml.bind.SchemaOutputResolver;


public class Controller {
    @FXML
    private AnchorPane anchor;

    @FXML
    private GridPane Grid;

    @FXML
    private Label label1;

    @FXML
    private Label label2;

    @FXML
    private Label label3;

    @FXML
    private Label label4;

    @FXML
    private Label label5;

    @FXML
    private Label label6;

    @FXML
    private Label label7;

    @FXML
    private Label label8;

    @FXML
    private Label label9;

    @FXML
    private Label label10;

    @FXML
    private Label label11;

    @FXML
    private Label label12;

    @FXML
    private Label label13;

    @FXML
    private Label label14;

    @FXML
    private Label label15;

    @FXML
    private Label label16;

    @FXML
    private Label label17;

    @FXML
    private Label label18;

    @FXML
    private Label label19;

    @FXML
    private Label label20;

    @FXML
    private Label label21;

    @FXML
    private Label label22;

    @FXML
    private Label label23;

    @FXML
    private Label label24;

    @FXML
    private Label label25;

    @FXML
    private Label label26;

    @FXML
    private Label label27;

    @FXML
    private Label label28;

    @FXML
    private Label label29;

    @FXML
    private Label label30;

    @FXML
    private Label label31;

    @FXML
    private Label label32;

    @FXML
    private Label label33;

    @FXML
    private Label label34;

    @FXML
    private Label label35;

    @FXML
    private Label label36;

    @FXML
    private Label label37;

    @FXML
    private Label label38;

    @FXML
    private Label label39;

    @FXML
    private Label label40;

    @FXML
    private Label label41;

    @FXML
    private Label label42;

    @FXML
    private Label label43;

    @FXML
    private Label label44;

    @FXML
    private Label label45;

    @FXML
    private Label label46;

    @FXML
    private Label label47;

    @FXML
    private Label label48;

    @FXML
    private Label label49;

    @FXML
    private Label label50;

    @FXML
    private Label label51;

    @FXML
    private Label label52;

    @FXML
    private Label label53;

    @FXML
    private Label label54;

    @FXML
    private Label label55;

    @FXML
    private Label label56;

    @FXML
    private Label label57;

    @FXML
    private Label label58;

    @FXML
    private Label label59;

    @FXML
    private Label label60;

    @FXML
    private Label label61;

    @FXML
    private Label label611;

    @FXML
    private Label label62;

    @FXML
    private Label label63;

    @FXML
    private Label label64;

    @FXML
    private Label label65;

    @FXML
    private Label label66;

    @FXML
    private Label label67;

    @FXML
    private Label label68;

    @FXML
    private Label label69;

    @FXML
    private Label label70;

    @FXML
    private Label label71;

    @FXML
    private Label label72;

    @FXML
    private Label label73;

    @FXML
    private Label label74;

    @FXML
    private Label label75;

    @FXML
    private Label label76;

    @FXML
    private Label label77;

    @FXML
    private Label label78;

    @FXML
    private Label label79;

    @FXML
    private Label label80;

    @FXML
    private Label label81;

    @FXML
    private Label label82;

    @FXML
    private Label label83;

    @FXML
    private Label label84;

    @FXML
    private Label label85;

    @FXML
    private Label label86;

    @FXML
    private Label label87;

    @FXML
    private Label label88;

    @FXML
    private Label label89;

    @FXML
    private Label label90;

    @FXML
    private Label label91;

    @FXML
    private Label label92;

    @FXML
    private Label label93;

    @FXML
    private Label label94;

    @FXML
    private Label label95;

    @FXML
    private Label label96;

    @FXML
    private Label label97;

    @FXML
    private Label label98;

    @FXML
    private Label label99;

    @FXML
    private Label label100;

    @FXML
    private Label label101;

    @FXML
    private Label label102;

    @FXML
    private Label label103;

    @FXML
    private Label label104;

    @FXML
    private Label label105;

    @FXML
    private Label label106;

    @FXML
    private Label label107;

    @FXML
    private Label label108;

    @FXML
    private Label label109;

    @FXML
    private Label label110;

    @FXML
    private Label label111;

    @FXML
    private Label label112;

    @FXML
    private Label label113;

    @FXML
    private Label label114;

    @FXML
    private Label label115;

    @FXML
    private Label label116;

    @FXML
    private Label label117;

    @FXML
    private Label label118;

    @FXML
    private Label label119;

    @FXML
    private Label label120;

    @FXML
    private Label label121;

    @FXML
    private Label label122;

    @FXML
    private Label label123;

    @FXML
    private Label label124;

    @FXML
    private Label label125;

    @FXML
    private Label label126;

    @FXML
    private Label label127;

    @FXML
    private Label label128;

    @FXML
    private Label label129;

    @FXML
    private Label label130;

    @FXML
    private Label label131;

    @FXML
    private Label label132;

    @FXML
    private Label label133;

    @FXML
    private Label label134;

    @FXML
    private Label label135;

    @FXML
    private Label label136;

    @FXML
    private Label label137;

    @FXML
    private Label label138;

    @FXML
    private Label label139;

    @FXML
    private Label label140;

    @FXML
    private Label label141;

    @FXML
    private Label label142;

    @FXML
    private Label label1423;

    @FXML
    private Label label143;

    @FXML
    private Label label144;

    @FXML
    private Label label145;

    @FXML
    private Label label146;

    @FXML
    private Label label147;

    @FXML
    private Label label148;

    @FXML
    private Label label149;

    @FXML
    private Label label150;

    @FXML
    private Label label151;

    @FXML
    private Label label152;

    @FXML
    private Label label153;

    @FXML
    private Label label154;



    public Label[][] labels;

    @FXML
    private Circle ball;

    @FXML
    public void initialize(){
        InitializeLabel();
    }




    public void InitializeLabel(){
        labels = new Label[12][13];
        labels[0][0]=label1;labels[0][1]=label2;labels[0][2]=label3;labels[0][3]=label4;labels[0][4]=label5;labels[0][5]=label6;labels[0][6]=label7; labels[0][7]=label8;labels[0][8]=label9;labels[0][9]=label10;labels[0][10]=label11;labels[0][11]=label12;labels[0][12]=label13;
        labels[1][0]=label14;labels[1][1]=label15;labels[1][2]=label16;labels[1][3]=label17;labels[1][4]=label18;labels[1][5]=label19;labels[1][6]=label20; labels[1][7]=label21;labels[1][8]=label22;labels[1][9]=label23;labels[1][10]=label24;labels[1][11]=label25;labels[1][12]=label26;
        labels[2][0]=label27;labels[2][1]=label28;labels[2][2]=label29;labels[2][3]=label30;labels[2][4]=label31;labels[2][5]=label32;labels[2][6]=label33; labels[2][7]=label34;labels[2][8]=label35;labels[2][9]=label36;labels[2][10]=label37;labels[2][11]=label38;labels[2][12]=label39;
        labels[3][0]=label40;labels[3][1]=label41;labels[3][2]=label42;labels[3][3]=label43;labels[3][4]=label44;labels[3][5]=label45;labels[3][6]=label46; labels[3][7]=label47;labels[3][8]=label48;labels[3][9]=label49;labels[3][10]=label50;labels[3][11]=label51;labels[3][12]=label52;
        labels[4][0]=label53;labels[4][1]=label54;labels[4][2]=label55;labels[4][3]=label56;labels[4][4]=label57;labels[4][5]=label58;labels[4][6]=label59; labels[4][7]=label60;labels[4][8]=label61;labels[4][9]=label611;labels[4][10]=label62;labels[4][11]=label63;labels[4][12]=label64;
        labels[5][0]=label65;labels[5][1]=label66;labels[5][2]=label67;labels[5][3]=label68;labels[5][4]=label69;labels[5][5]=label70;labels[5][6]=label71; labels[5][7]=label72;labels[5][8]=label73;labels[5][9]=label74;labels[5][10]=label75;labels[5][11]=label76;labels[5][12]=label77;
        labels[6][0]=label78;labels[6][1]=label79;labels[6][2]=label80;labels[6][3]=label81;labels[6][4]=label82;labels[6][5]=label83;labels[6][6]=label84; labels[6][7]=label85;labels[6][8]=label86;labels[6][9]=label87;labels[6][10]=label88;labels[6][11]=label89;labels[6][12]=label90;
        labels[7][0]=label91;labels[7][1]=label92;labels[7][2]=label93;labels[7][3]=label94;labels[7][4]=label95;labels[7][5]=label96;labels[7][6]=label97; labels[7][7]=label98;labels[7][8]=label99;labels[7][9]=label100;labels[7][10]=label101;labels[7][11]=label102;labels[7][12]=label103;
        labels[8][0]=label104;labels[8][1]=label105;labels[8][2]=label106;labels[8][3]=label107;labels[8][4]=label108;labels[8][5]=label109;labels[8][6]=label110; labels[8][7]=label111;labels[8][8]=label112;labels[8][9]=label113;labels[8][10]=label114;labels[8][11]=label115;labels[8][12]=label116;
        labels[9][0]=label117;labels[9][1]=label118;labels[9][2]=label119;labels[9][3]=label120;labels[9][4]=label121;labels[9][5]=label122;labels[9][6]=label123; labels[9][7]=label124;labels[9][8]=label125;labels[9][9]=label126;labels[9][10]=label127;labels[9][11]=label128;labels[9][12]=label129;
        labels[10][0]=label130;labels[10][1]=label131;labels[10][2]=label132;labels[10][3]=label133;labels[10][4]=label134;labels[10][5]=label135;labels[10][6]=label136; labels[10][7]=label137;labels[10][8]=label138;labels[10][9]=label139;labels[10][10]=label140;labels[10][11]=label141;labels[10][12]=label142;
        labels[11][0]=label1423;labels[11][1]=label143;labels[11][2]=label144;labels[11][3]=label145;labels[11][4]=label146;labels[11][5]=label147;labels[11][6]=label148; labels[11][7]=label149;labels[11][8]=label150;labels[11][9]=label151;labels[11][10]=label152;labels[11][11]=label153;labels[11][12]=label154;
        System.out.println("Joha");
    }

    public void KeyPressed() {

    }
    public int ballX,ballY;

    public int map[][] = {
            {1,1,1,1,1,1,1,1,1,1,1,1,1},
            {1,2,1,0,0,0,1,1,1,1,1,1,1},
            {1,0,1,0,1,0,0,0,0,0,0,1,1},
            {1,0,1,0,0,0,1,1,1,1,0,0,1},
            {1,0,0,0,1,1,1,1,1,1,1,0,1},
            {1,0,1,1,1,1,1,0,0,0,0,0,1},
            {1,0,1,0,0,0,1,0,0,0,1,1,1},
            {1,0,1,0,1,0,1,0,1,1,1,1,1},
            {1,0,0,0,1,0,1,0,1,1,1,1,1},
            {1,1,1,1,1,0,0,0,1,1,1,1,1},
            {1,1,1,1,1,1,1,1,1,1,1,1,1},
    };
    @FXML
    void ballAction(ActionEvent event) {


        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                if(map[i][j]== 2){
                    ballX = i;
                    ballY = j;

                }
            }
        }
        System.out.println("Shykty");

        while (map[ballX][ballY] != 1){
            map[ballX][ballY] = 0;
            labels[ballX][ballY].setStyle("-fx-background-color:yellow");
            ballX++;


        }

        ballX = ballX-1;
        map[ballX][ballY] = 2;
        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                System.out.print(map[i][j]);
            }
            System.out.println();
        }
        Grid.add(ball,ballY,ballX);



    }

    @FXML
    void TopAction(ActionEvent event) {

        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                if(map[i][j]== 2){
                    ballX = i;
                    ballY = j;

                }
            }
        }
        System.out.println("Shykty");

        while (map[ballX][ballY] != 1){
            map[ballX][ballY] = 0;
            labels[ballX][ballY].setStyle("-fx-background-color:yellow");
            ballX--;


        }

        ballX = ballX+1;
        map[ballX][ballY] = 2;
        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                System.out.print(map[i][j]);
            }
            System.out.println();
        }
        Grid.add(ball,ballY,ballX);
    }

    @FXML
    void rightAction(ActionEvent event) {
        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                if(map[i][j]== 2){
                    ballX = i;
                    ballY = j;

                }
            }
        }
        System.out.println("BAllx --> "+ ballX);
        System.out.println("BAlly --> "+ ballY);
        while (map[ballX][ballY] != 1){
            map[ballX][ballY] = 0;
            labels[ballX][ballY].setStyle("-fx-background-color:yellow");
            ++ballY;


        }
        ballY = ballY - 1;
        map[ballX][ballY] = 2;
        Grid.add(ball,ballY,ballX);

    }


    @FXML
    void leftAction(ActionEvent event) {
        for(int i = 0; i < 11;i++) {
            for (int j = 0; j < 13; j++) {
                if(map[i][j]== 2){
                    ballX = i;
                    ballY = j;

                }
            }
        }
        System.out.println("BAllx --> "+ ballX);
        System.out.println("BAlly --> "+ ballY);
        while (map[ballX][ballY] != 1){
            map[ballX][ballY] = 0;
            labels[ballX][ballY].setStyle("-fx-background-color:yellow");
            --ballY;


        }
        ballY = ballY + 1;
        map[ballX][ballY] = 2;
        Grid.add(ball,ballY,ballX);


    }

    @FXML
    void btnAction(ActionEvent event) {


        for(int i = 0; i < 11;i++){
            for(int j = 0;j < 13; j++){
                if(map[i][j] == 0)
                    labels[i][j].setStyle("-fx-background-color:red");
                else
                    if(map[i][j] == 1)
                        labels[i][j].setStyle("-fx-background-color:black");

            }
        }
    }





}
